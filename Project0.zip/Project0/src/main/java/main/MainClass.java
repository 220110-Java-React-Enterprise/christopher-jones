package main;

import views.MainMenu;
import views.SubMenu;
import views.ViewManager;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connection.ConnectionManager;

public class MainClass {
    public static void main(String[] args) throws SQLException, IOException {

        Connection connector = ConnectionManager.getConnection();

        try {
            String sql = "INSERT INTO test_table (string) VALUES (?)";
            PreparedStatement pstmt = connector.prepareStatement(sql);
            pstmt.setString( parameterIndex: 1, x: "test string");
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();

            rs.next();
            int idByIndex = rs.getInt(columnIndex: 1);
            int idByName = rs.getInt(columnLabel: "id");

            System.out.println("IDs: " + idByIndex + ", " + idByName);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        ViewManager viewManager = ViewManager.getViewManager();

        viewManager.registerView(new MainMenu());
        viewManager.registerView(new SubMenu());

        viewManager.navigate("MainMenu");

        while(viewManager.isRunning()) {
            viewManager.render();
        }

    }
}
