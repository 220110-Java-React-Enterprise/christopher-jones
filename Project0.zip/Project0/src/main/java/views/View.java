package views;

import connection.AccountModel;

public abstract class View {

    protected String viewName;
    protected ViewManager viewManager;

    AccountModel viewAccounts = new AccountModel();

    public String getViewName() {
        return viewName;
    }

    public abstract void renderView();
}
