package views;

public class MainMenu extends View{

    public MainMenu() {
        viewName = "MainMenu";
        viewManager = ViewManager.getViewManager();
    }

    @Override
    public void renderView() {
        //prompt user
        System.out.println("========== Main Menu ==========");
        System.out.println("If you are a new user, type \"new\"");
        System.out.println("If you are an existing user, type \"login\"");
        //grab login input
        String currentCheck = viewManager.getScanner().nextLine();

        System.out.println("Enter name: ");

        //get input from user
        String input = viewManager.getScanner().nextLine();

        //preform validation?

        //store this for use later
        viewAccounts.setUsername(input);


        //navigate to next menu
        viewManager.navigate("SubMenu");

    }
}
