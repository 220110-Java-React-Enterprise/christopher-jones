package connection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountRepo implements DataSourceCRUD<AccountModel>{
    private final Connection connection;

    public AccountRepo() {
        connection = ConnectionManager.getConnection();
    }

    @Override
    public AccountModel create(AccountModel model) {
        //JDBC logic here

        try {
            String sql = "INSERT INTO accounts (account_num, account_bal, user_name, password) VALUES (?,?,?,?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, model.getAccountNumber());
            pstmt.setDouble(2, model.getAccountBalance());
            pstmt.setString(3, model.getUsername());
            pstmt.setString(4, model.getPassword());

            pstmt.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return model;
    }

    @Override
    public AccountModel read(Integer id) {
        try {
            String sql = "SELECT * FROM accounts WHERE account_num = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, id);

            ResultSet rs = pstmt.executeQuery();

            AccountModel model = new AccountModel();
            while(rs.next()) {
                model.setAccountNumber(rs.getInt("account_num"));
                model.setAccountBalance(rs.getDouble("account_bal"));
                model.setUsername(rs.getString("user_name"));
                model.setPassword(rs.getString("password"));
            }

            return model;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public AccountModel update(AccountModel model) {
        try {
            String sql = "UPDATE accounts SET user_name = ?, password = ?, account_bal = ? WHERE account_num = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, model.getUsername());
            pstmt.setString(2, model.getPassword());
            pstmt.setDouble(3, model.getAccountBalance());
            pstmt.setInt(4, model.getAccountNumber());


            pstmt.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return model;
    }

    @Override
    public void delete(Integer id) {
        try {
            String sql = "DELETE FROM accounts WHERE account_num = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}